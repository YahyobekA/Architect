package dev.architect;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.Shulker;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public final class Drops {
    public static void onDeath(LivingEntity e, DamageSource source) {
        if (!(e.level() instanceof ServerLevel level)) return;
        var rnd = level.getRandom();

        // Эссенция жизни: 1% с врагов (50% с дракона), количество 1-10
        double chance = e instanceof EnderDragon ? 0.50 : (e instanceof Enemy ? 0.01 : 0.0);
        if (chance > 0 && rnd.nextDouble() < chance) {
            drop(level, e, ModItems.LIFE_ESSENCE, 1 + rnd.nextInt(10));
        }
        // Фрагмент разлома: эндермен ~3%, шалкер ~10%
        if (e instanceof EnderMan && rnd.nextDouble() < 0.03) drop(level, e, ModItems.RIFT_FRAGMENT, 1);
        if (e instanceof Shulker && rnd.nextDouble() < 0.10) drop(level, e, ModItems.RIFT_FRAGMENT, 1);
    }

    private static void drop(ServerLevel level, LivingEntity e, Item item, int count) {
        e.spawnAtLocation(level, new ItemStack(item, count));
    }
}
