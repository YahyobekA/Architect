package dev.architect;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.*;

public final class Rifts {
    public static final ResourceKey<Level>[] WORLDS = new ResourceKey[]{Level.OVERWORLD, Level.NETHER, Level.END};
    public static final String[] NAMES = {"Обычный мир", "Незер", "Энд"};
    public static final int LIFETIME_TICKS = 30 * 20;

    private static final Map<UUID, Integer> modes = new HashMap<>();
    private static final List<Rift> active = new ArrayList<>();

    private record Rift(ServerLevel level, Vec3 pos, ServerLevel destLevel, BlockPos dest, long expire) {}

    public static int mode(UUID id) { return modes.getOrDefault(id, 1); }

    public static int cycle(UUID id) {
        int m = (mode(id) + 1) % WORLDS.length;
        modes.put(id, m);
        return m;
    }

    /** Пытается открыть разлом. false = не получилось (предмет не тратится). */
    public static boolean open(ServerPlayer player, Vec3 landing) {
        MinecraftServer server = player.level().getServer();
        ServerLevel from = player.level();
        ResourceKey<Level> toKey = WORLDS[mode(player.getUUID())];
        if (from.dimension() == toKey) {
            player.displayClientMessage(Component.literal("§cВы уже в этом мире"), true);
            return false;
        }
        ServerLevel to = server.getLevel(toKey);
        if (to == null) return false;

        BlockPos dest;
        if (toKey == Level.END) {
            dest = new BlockPos(100, 49, 0); // обсидиановая платформа
            buildEndPlatform(to);
        } else {
            double x = landing.x, z = landing.z;
            if (from.dimension() == Level.OVERWORLD && toKey == Level.NETHER) { x /= 8; z /= 8; }
            if (from.dimension() == Level.NETHER && toKey == Level.OVERWORLD) { x *= 8; z *= 8; }
            int minY = to.getMinY() + 2, maxY = to.getMaxY() - 4;
            if (toKey == Level.NETHER) { minY = 5; maxY = 120; }
            int y = Math.max(minY, Math.min(maxY, (int) landing.y));
            dest = BlockPos.containing(x, y, z);
            to.getChunk(dest); // загрузить чанк
            for (BlockPos p : new BlockPos[]{dest, dest.above()}) {
                BlockState s = to.getBlockState(p);
                if (s.getDestroySpeed(to, p) < 0 || s.is(Blocks.OBSIDIAN)
                        || s.is(Blocks.CRYING_OBSIDIAN) || s.is(Blocks.RESPAWN_ANCHOR)) {
                    player.displayClientMessage(Component.literal("§cРазлом открыть не получится"), true);
                    return false;
                }
            }
            for (BlockPos p : new BlockPos[]{dest, dest.above()}) {
                if (!to.getBlockState(p).isAir()) to.destroyBlock(p, false);
            }
        }
        active.add(new Rift(from, landing, to, dest, server.getTickCount() + LIFETIME_TICKS));
        return true;
    }

    private static void buildEndPlatform(ServerLevel end) {
        for (int dx = -2; dx <= 2; dx++)
            for (int dz = -2; dz <= 2; dz++) {
                end.setBlockAndUpdate(new BlockPos(100 + dx, 48, dz), Blocks.OBSIDIAN.defaultBlockState());
                for (int dy = 49; dy <= 51; dy++)
                    end.setBlockAndUpdate(new BlockPos(100 + dx, dy, dz), Blocks.AIR.defaultBlockState());
            }
    }

    public static void tick(MinecraftServer server, int t) {
        Iterator<Rift> it = active.iterator();
        while (it.hasNext()) {
            Rift r = it.next();
            if (t >= r.expire) { it.remove(); continue; }
            if (t % 2 == 0) {
                r.level.sendParticles(ParticleTypes.PORTAL, r.pos.x, r.pos.y + 1, r.pos.z, 12, 0.3, 0.7, 0.3, 0.2);
                r.level.sendParticles(ParticleTypes.REVERSE_PORTAL, r.pos.x, r.pos.y + 1, r.pos.z, 4, 0.2, 0.5, 0.2, 0.05);
            }
            for (ServerPlayer p : r.level.getPlayers(pl -> pl.position().distanceToSqr(r.pos) < 2.5)) {
                p.teleportTo(r.destLevel, r.dest.getX() + 0.5, r.dest.getY(), r.dest.getZ() + 0.5,
                        Set.of(), p.getYRot(), p.getXRot(), true);
            }
        }
    }
}
