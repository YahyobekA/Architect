package dev.architect;

import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;

public final class Tick {
    public static void onTick(MinecraftServer server) {
        int t = server.getTickCount();

        // Ограничение: элитра работает только в Энде
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (p.isFallFlying() && p.level().dimension() != Level.END) {
                p.stopFallFlying();
                if (t % 20 == 0) {
                    p.displayClientMessage(Component.literal("§cЭлитра работает только в Энде"), true);
                }
            }
        }

        Rifts.tick(server, t);
        if (t % 20 == 0) {
            Jammer.tick(server);
            Tracker.tick(server);
        }
    }
}
