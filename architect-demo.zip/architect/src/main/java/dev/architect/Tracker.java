package dev.architect;

import dev.architect.item.TrackerCompassItem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.LodestoneTracker;
import net.minecraft.world.level.Level;

import java.util.*;

/** Кто за кем следит. Для демо хранится в памяти (после перезапуска сбрасывается). */
public final class Tracker {
    private static final Map<UUID, UUID> targets = new HashMap<>();
    // Несуществующее измерение: ванильный компас в таком случае "крутится"
    private static final ResourceKey<Level> FAKE_DIM =
            ResourceKey.create(Registries.DIMENSION, Architect.id("void"));

    public static UUID targetOf(UUID owner) { return targets.get(owner); }
    public static void setTarget(UUID owner, UUID target) { targets.put(owner, target); }
    public static void clear(UUID owner) { targets.remove(owner); }

    public static void tick(MinecraftServer server) {
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            Inventory inv = p.getInventory();
            GlobalPos pos = compute(server, p);
            LodestoneTracker tracker = new LodestoneTracker(Optional.of(pos), false);
            for (int i = 0; i < inv.getContainerSize(); i++) {
                ItemStack s = inv.getItem(i);
                if (s.getItem() instanceof TrackerCompassItem
                        && !tracker.equals(s.get(DataComponents.LODESTONE_TRACKER))) {
                    s.set(DataComponents.LODESTONE_TRACKER, tracker);
                }
            }
        }
    }

    private static GlobalPos compute(MinecraftServer server, ServerPlayer owner) {
        GlobalPos spin = GlobalPos.of(FAKE_DIM, BlockPos.ZERO);
        UUID tid = targets.get(owner.getUUID());
        if (tid == null) return spin;
        ServerPlayer t = server.getPlayerList().getPlayer(tid);
        if (t == null || Jammer.isActive(tid)) return spin;
        // Другое измерение -> клиентский компас сам крутится
        return GlobalPos.of(t.level().dimension(), t.blockPosition());
    }
}
