package dev.architect;

import dev.architect.item.*;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.util.function.Function;

public final class ModItems {
    // Материалы (не крафтятся, падают с мобов/боссов)
    public static Item VOID_ESSENCE, REALITY_SHARD, RIFT_FRAGMENT, LIFE_ESSENCE;
    // Промежуточные
    public static Item AMETHYST_CRYSTAL, WORLD_MIX;
    // Предметы
    public static Item HEALING_CRYSTAL, TRACKER_COMPASS, JAMMER_MAGNET, RIFT;

    private static <T extends Item> T reg(String name, String title, int stack,
                                          Function<Item.Properties, T> factory) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Architect.id(name));
        Item.Properties p = new Item.Properties().setId(key).stacksTo(stack)
                .component(DataComponents.ITEM_NAME, Component.literal(title));
        return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(p));
    }

    private static BaseItem simple(String name, String title) {
        return reg(name, title, 64, p -> new BaseItem(p, Items.AMETHYST_SHARD, name));
    }

    public static void init() {
        VOID_ESSENCE = simple("void_essence", "Эссенция Пустоты");
        REALITY_SHARD = simple("reality_shard", "Осколок реальности");
        RIFT_FRAGMENT = simple("rift_fragment", "Фрагмент разлома");
        LIFE_ESSENCE = simple("life_essence", "Эссенция жизни");
        AMETHYST_CRYSTAL = simple("amethyst_crystal", "Аметистовый кристалл");
        WORLD_MIX = simple("world_mix", "Смесь миров");

        HEALING_CRYSTAL = reg("healing_crystal", "Исцеляющий кристалл", 64,
                p -> new HealingCrystalItem(p, Items.AMETHYST_SHARD, "healing_crystal"));
        TRACKER_COMPASS = reg("tracker_compass", "Компас слежения", 1,
                p -> new TrackerCompassItem(p));
        JAMMER_MAGNET = reg("jammer_magnet", "Магнит-помеха", 1,
                p -> new JammerMagnetItem(p, Items.AMETHYST_SHARD, "jammer_magnet"));
        RIFT = reg("rift", "Разлом", 16,
                p -> new RiftItem(p, Items.AMETHYST_SHARD, "rift"));
    }
}
