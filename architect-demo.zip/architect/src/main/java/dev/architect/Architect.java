package dev.architect;

import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.resources.Identifier;

public class Architect implements ModInitializer {
    public static final String ID = "architect";

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(ID, path);
    }

    @Override
    public void onInitialize() {
        ModItems.init();
        PolymerResourcePackUtils.addModAssets(ID);
        PolymerResourcePackUtils.markAsRequired();
        ServerTickEvents.END_SERVER_TICK.register(Tick::onTick);
        ServerLivingEntityEvents.AFTER_DEATH.register(Drops::onDeath);
    }
}
