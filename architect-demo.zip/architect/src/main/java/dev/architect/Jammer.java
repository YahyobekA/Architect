package dev.architect;

import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.*;

/** Состояние магнита-помехи: 10 минут работы, затем 10 минут перезарядки. */
public final class Jammer {
    public static final long DURATION = 10 * 60 * 1000L;
    public static final long COOLDOWN = 10 * 60 * 1000L;

    private static final Map<UUID, Long> activeUntil = new HashMap<>();
    private static final Map<UUID, Long> cooldownUntil = new HashMap<>();

    public static boolean isActive(UUID id) {
        Long t = activeUntil.get(id);
        return t != null && t > System.currentTimeMillis();
    }

    public static void toggle(ServerPlayer p) {
        UUID id = p.getUUID();
        long now = System.currentTimeMillis();
        if (isActive(id)) {
            stop(p);
            return;
        }
        long cd = cooldownUntil.getOrDefault(id, 0L);
        if (cd > now) {
            p.displayClientMessage(Component.literal("§cПерезарядка: " + fmt(cd - now)), true);
            return;
        }
        activeUntil.put(id, now + DURATION);
        p.displayClientMessage(Component.literal("§aПомеха включена"), true);
        // Те, кто следил за игроком, получают сообщение
        p.level().getServer().getPlayerList().getPlayers().forEach(o -> {
            if (p.getUUID().equals(Tracker.targetOf(o.getUUID()))) {
                o.displayClientMessage(Component.literal("§eКомпас запутался"), false);
            }
        });
    }

    private static void stop(ServerPlayer p) {
        activeUntil.remove(p.getUUID());
        cooldownUntil.put(p.getUUID(), System.currentTimeMillis() + COOLDOWN);
        p.displayClientMessage(Component.literal("§7Помеха выключена, перезарядка 10:00"), true);
    }

    public static void tick(MinecraftServer server) {
        long now = System.currentTimeMillis();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            Long until = activeUntil.get(p.getUUID());
            if (until == null) continue;
            if (until <= now) {
                stop(p);
            } else {
                p.displayClientMessage(Component.literal("§bПомеха: " + fmt(until - now)), true);
            }
        }
    }

    private static String fmt(long ms) {
        long s = Math.max(0, ms / 1000);
        return String.format("%d:%02d", s / 60, s % 60);
    }
}
