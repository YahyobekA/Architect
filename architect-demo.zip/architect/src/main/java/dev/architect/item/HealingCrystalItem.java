package dev.architect.item;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/** Одноразовый: лечит владельца на 1 сердце (2 HP). */
public class HealingCrystalItem extends BaseItem {
    public HealingCrystalItem(Properties p, Item vanilla, String model) {
        super(p, vanilla, model);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!(level instanceof ServerLevel sl)) return InteractionResult.SUCCESS;
        if (player.getHealth() >= player.getMaxHealth()) {
            player.displayClientMessage(Component.literal("§cЗдоровье уже полное"), true);
            return InteractionResult.FAIL;
        }
        player.heal(2.0f);
        sl.sendParticles(ParticleTypes.HEART, player.getX(), player.getY() + 1.8, player.getZ(),
                6, 0.4, 0.3, 0.4, 0.0);
        sl.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME,
                SoundSource.PLAYERS, 1.0f, 1.2f);
        player.getItemInHand(hand).consume(1, player);
        return InteractionResult.SUCCESS;
    }
}
