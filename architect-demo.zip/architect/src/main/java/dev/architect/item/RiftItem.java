package dev.architect.item;

import dev.architect.Rifts;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.Level;

public class RiftItem extends BaseItem {
    public RiftItem(Properties p, Item vanilla, String model) {
        super(p, vanilla, model);
    }

    /**
     * ДЕМО-УПРОЩЕНИЕ: вместо настоящего броска разлом открывается в точке,
     * куда смотрит игрок (до 30 блоков). Полноценный бросок будет в следующей версии.
     */
    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!(player instanceof ServerPlayer sp) || !(level instanceof ServerLevel)) {
            return InteractionResult.SUCCESS;
        }
        if (sp.isShiftKeyDown()) {
            int m = Rifts.cycle(sp.getUUID());
            sp.displayClientMessage(Component.literal("§dРазлом ведёт в: " + Rifts.NAMES[m]), true);
            return InteractionResult.SUCCESS;
        }
        HitResult hit = sp.pick(30.0, 0f, false);
        if (hit.getType() == HitResult.Type.MISS) {
            sp.displayClientMessage(Component.literal("§cСмотрите на поверхность"), true);
            return InteractionResult.FAIL;
        }
        if (Rifts.open(sp, hit.getLocation())) {
            if (!sp.isCreative()) sp.getItemInHand(hand).shrink(1);
        }
        return InteractionResult.SUCCESS;
    }
}
