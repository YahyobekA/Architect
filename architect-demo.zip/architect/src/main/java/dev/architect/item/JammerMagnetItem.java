package dev.architect.item;

import dev.architect.Jammer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

public class JammerMagnetItem extends BaseItem {
    public JammerMagnetItem(Properties p, Item vanilla, String model) {
        super(p, vanilla, model);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (player instanceof ServerPlayer sp) Jammer.toggle(sp);
        return InteractionResult.SUCCESS;
    }
}
