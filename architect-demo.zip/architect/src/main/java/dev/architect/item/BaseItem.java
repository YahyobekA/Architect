package dev.architect.item;

import dev.architect.Architect;
import eu.pb4.polymer.core.api.item.PolymerItem;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import xyz.nucleoid.packettweaker.PacketContext;

/** Базовый предмет: на клиенте выглядит как ванильный, но с моделью из ресурспака. */
public class BaseItem extends Item implements PolymerItem {
    private final Item vanilla;
    private final Identifier model;

    public BaseItem(Properties props, Item vanilla, String modelName) {
        super(props);
        this.vanilla = vanilla;
        this.model = modelName == null ? null : Architect.id(modelName);
    }

    @Override
    public Item getPolymerItem(ItemStack stack, PacketContext ctx) {
        return vanilla;
    }

    @Override
    public Identifier getPolymerItemModel(ItemStack stack, PacketContext ctx) {
        return model;
    }
}
