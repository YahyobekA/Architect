package dev.architect.item;

import dev.architect.Jammer;
import dev.architect.Tracker;
import eu.pb4.sgui.api.elements.GuiElementBuilder;
import eu.pb4.sgui.api.gui.SimpleGui;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ResolvableProfile;
import net.minecraft.world.level.Level;
import xyz.nucleoid.packettweaker.PacketContext;

public class TrackerCompassItem extends BaseItem {
    public TrackerCompassItem(Properties p) {
        super(p, Items.COMPASS, null);
    }

    // Своей модели нет: нужна ванильная стрелка компаса
    @Override
    public Identifier getPolymerItemModel(ItemStack stack, PacketContext ctx) {
        return null;
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!(player instanceof ServerPlayer sp)) return InteractionResult.SUCCESS;
        SimpleGui gui = new SimpleGui(MenuType.GENERIC_9x5, sp, false);
        gui.setTitle(Component.literal("Выберите игрока"));
        int slot = 0;
        for (ServerPlayer p : sp.level().getServer().getPlayerList().getPlayers()) {
            if (p == sp || slot >= 44) continue;
            ItemStack head = new ItemStack(Items.PLAYER_HEAD);
            head.set(DataComponents.PROFILE, ResolvableProfile.createResolved(p.getGameProfile()));
            gui.setSlot(slot++, GuiElementBuilder.from(head)
                    .setName(Component.literal(p.getGameProfile().name()))
                    .setCallback((i, t, a, g) -> {
                        if (Jammer.isActive(p.getUUID())) {
                            sp.displayClientMessage(Component.literal("§eКомпас запутался"), false);
                        } else {
                            Tracker.setTarget(sp.getUUID(), p.getUUID());
                        }
                        gui.close();
                    }));
        }
        gui.setSlot(44, new GuiElementBuilder(Items.BARRIER)
                .setName(Component.literal("§cОтключить слежение"))
                .setCallback((i, t, a, g) -> { Tracker.clear(sp.getUUID()); gui.close(); }));
        gui.open();
        return InteractionResult.SUCCESS;
    }
}
