"""Генерирует текстуры 16x16, модели и рецепты. Запуск: python3 tools/gen.py"""
import zlib, struct, json, os, math
R = "src/main/resources"
TEX, MOD, ITM = f"{R}/assets/architect/textures/item", f"{R}/assets/architect/models/item", f"{R}/assets/architect/items"
REC = f"{R}/data/architect/recipe"

def png(path, px):
    raw = b"".join(b"\x00" + bytes(c for p in row for c in p) for row in px)
    def ch(t, d): return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    open(path, "wb").write(b"\x89PNG\r\n\x1a\n" + ch(b"IHDR", struct.pack(">IIBBBBB", 16, 16, 8, 6, 0, 0, 0))
                           + ch(b"IDAT", zlib.compress(raw)) + ch(b"IEND", b""))

def shade(c, f): return tuple(max(0, min(255, int(v * f))) for v in c) + (255,)

def draw(mask, base):
    inside = [[mask(x, y) for x in range(16)] for y in range(16)]
    def at(x, y): return 0 <= x < 16 and 0 <= y < 16 and inside[y][x]
    out = [[(0, 0, 0, 0)] * 16 for _ in range(16)]
    for y in range(16):
        for x in range(16):
            if not inside[y][x]: continue
            edge = not (at(x-1, y) and at(x+1, y) and at(x, y-1) and at(x, y+1))
            if edge: out[y][x] = shade(base, 0.45)
            elif not at(x-1, y-1) or not at(x, y-2) or not at(x-2, y): out[y][x] = shade(base, 1.35)
            elif not at(x+1, y+1) or not at(x+2, y): out[y][x] = shade(base, 0.8)
            else: out[y][x] = shade(base, 1.0)
    return out

cx = 7.5
def gem(x, y): return abs(x-cx)/6.5 + abs(y-8)/7.5 <= 1
def drop(x, y): return (x-cx)**2 + (y-10)**2 <= 25 or (2 <= y <= 9 and abs(x-cx) <= (y-2)*0.75)
def shard(x, y): return 1 <= y <= 14 and abs(x-cx) <= 0.5 + (y-1)*0.42
def ring(x, y): return 3.8 <= math.hypot(x-cx, y-cx) <= 6.6
def blob(x, y): return math.hypot(x-cx, y-cx) <= 6.2
def magnet(x, y):
    d = math.hypot(x-cx, y-9)
    return (3 <= d <= 6.5 and y >= 8) or (y < 8 and (2 <= x <= 5 or 10 <= x <= 13) and y >= 2 and (abs(x-3.5) <= 1.6 or abs(x-11.5) <= 1.6))
def rift(x, y): return 4.5 <= math.hypot((x-cx)*0.8, y-cx) <= 7 or math.hypot(x-cx, y-cx) <= 1.6
def frag(x, y): return abs(x-cx) + abs(y-cx)*0.6 <= 6 and (x + y) % 5 != 0 or abs(x-cx) <= 1 and 2 <= y <= 13

ITEMS = {
    "void_essence":     (drop,   (90, 30, 140)),
    "reality_shard":    (shard,  (240, 240, 255)),
    "rift_fragment":    (frag,   (150, 70, 220)),
    "life_essence":     (drop,   (230, 60, 90)),
    "amethyst_crystal": (gem,    (170, 110, 230)),
    "world_mix":        (blob,   (80, 190, 150)),
    "healing_crystal":  (gem,    (255, 110, 150)),
    "jammer_magnet":    (magnet, (210, 50, 50)),
    "rift":             (rift,   (120, 60, 200)),
}
for d in (TEX, MOD, ITM, REC): os.makedirs(d, exist_ok=True)
for name, (mask, col) in ITEMS.items():
    png(f"{TEX}/{name}.png", draw(mask, col))
    json.dump({"parent": "minecraft:item/generated", "textures": {"layer0": f"architect:item/{name}"}}, open(f"{MOD}/{name}.json", "w"))
    json.dump({"model": {"type": "minecraft:model", "model": f"architect:item/{name}"}}, open(f"{ITM}/{name}.json", "w"))

def shapeless(name, ings, result, count=1):
    json.dump({"type": "minecraft:crafting_shapeless", "category": "misc",
               "ingredients": ings, "result": {"id": f"architect:{result}", "count": count}},
              open(f"{REC}/{name}.json", "w"), indent=2)

m = lambda s: "minecraft:" + s
shapeless("amethyst_crystal", [m("amethyst_shard")]*4 + [m("gold_ingot")]*2 + [m("diamond"), m("redstone_block")], "amethyst_crystal")
shapeless("healing_crystal", ["architect:amethyst_crystal", "architect:life_essence"], "healing_crystal")
shapeless("world_mix", ["architect:rift_fragment"]*4 + [m("echo_shard")]*2 + [m("ancient_debris")]*2 + [m("heart_of_the_sea")], "world_mix")
shapeless("tracker_compass", [m("compass"), m("gold_ingot"), m("gold_ingot"), m("redstone"), m("redstone"), m("amethyst_shard"), m("ender_pearl")], "tracker_compass")
shapeless("jammer_magnet", [m("netherite_ingot"), m("ender_pearl"), m("ender_pearl"), m("redstone_block"), m("redstone_block"),
                            m("amethyst_shard"), m("amethyst_shard"), m("iron_block"), m("lodestone")], "jammer_magnet")
shapeless("rift", ["architect:rift_fragment"]*4 + [m("echo_shard")]*2 + [m("ender_pearl")]*2 + [m("lodestone")], "rift", 2)
print("ok")
